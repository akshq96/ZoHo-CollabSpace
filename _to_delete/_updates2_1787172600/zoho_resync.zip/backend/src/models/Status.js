const mongoose = require('mongoose');

const storySchema = new mongoose.Schema({
    mediaUrl: { type: String, required: true },
    mediaType: { type: String, enum: ['image', 'video'], default: 'image' },
    caption: { type: String, default: '' },
    createdAt: { type: Date, default: Date.now }
});

const statusSchema = new mongoose.Schema({
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    stories: [storySchema],
    expiresAt: { type: Date, required: true }
}, { timestamps: true });

// TTL index to automatically delete status documents when expiresAt is reached
statusSchema.index({ expiresAt: 1 }, { expireAfterSeconds: 0 });

const Status = mongoose.model('Status', statusSchema);
module.exports = Status;
