const Conversation = require('../models/Conversation');
const User = require('../models/User');
const response = require('../utils/responseHandler');

const createOrGetConversation = async (req, res) => {
    const { receiverId } = req.body;
    const senderId = req.user._id;

    if (!receiverId) {
        return response(res, 400, "Receiver ID is required");
    }

    try {
        // Check if receiver exists
        const receiver = await User.findById(receiverId);
        if (!receiver) {
            return response(res, 404, "Receiver not found");
        }

        // Check if conversation already exists
        let conversation = await Conversation.findOne({
            participants: { $all: [senderId, receiverId] }
        }).populate('participants', 'username profilePicture about isOnline lastSeen');

        if (!conversation) {
            conversation = new Conversation({
                participants: [senderId, receiverId],
                unreadcount: 0
            });
            await conversation.save();
            conversation = await conversation.populate('participants', 'username profilePicture about isOnline lastSeen');
        }

        return response(res, 200, "Conversation retrieved/created successfully", conversation);
    } catch (error) {
        console.error("Error in createOrGetConversation:", error);
        return response(res, 500, "Internal Server Error");
    }
};

const getConversations = async (req, res) => {
    const userId = req.user._id;

    try {
        // Find conversations where the user is a participant
        const conversations = await Conversation.find({
            participants: userId
        })
        .populate('participants', 'username profilePicture about isOnline lastSeen')
        .populate({
            path: 'lastMessage',
            populate: {
                path: 'sender receiver',
                select: 'username profilePicture'
            }
        })
        .sort({ updatedAt: -1 });

        return response(res, 200, "Conversations retrieved successfully", conversations);
    } catch (error) {
        console.error("Error in getConversations:", error);
        return response(res, 500, "Internal Server Error");
    }
};

const createGroupConversation = async (req, res) => {
    const { groupName, participants } = req.body;
    const adminId = req.user._id;

    if (!groupName || !participants || !Array.isArray(participants) || participants.length === 0) {
        return response(res, 400, "Group name and participants list are required");
    }

    try {
        // Ensure admin is included in participants
        const uniqueParticipants = Array.from(new Set([...participants, adminId.toString()]));

        // Generate dynamic group avatar
        const groupAvatar = `https://api.dicebear.com/7.x/identicon/svg?seed=${encodeURIComponent(groupName)}`;

        const newGroup = new Conversation({
            participants: uniqueParticipants,
            isGroup: true,
            groupName,
            groupAdmin: adminId,
            groupAvatar
        });

        await newGroup.save();

        const populatedGroup = await Conversation.findById(newGroup._id)
            .populate('participants', 'username profilePicture about isOnline lastSeen')
            .populate('groupAdmin', 'username profilePicture');

        return response(res, 201, "Group conversation created successfully", populatedGroup);
    } catch (error) {
        console.error("Error in createGroupConversation:", error);
        return response(res, 500, "Internal Server Error");
    }
};

module.exports = { createOrGetConversation, getConversations, createGroupConversation };
