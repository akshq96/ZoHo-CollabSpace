const User = require('../models/User');
const response = require('../utils/responseHandler');

const getAllUsers = async (req, res) => {
    const activeUserId = req.user._id;

    try {
        // Fetch all users except the currently logged-in user
        const users = await User.find({ _id: { $ne: activeUserId } })
            .select('-emailOtp -emailOtpExpiry');
        return response(res, 200, "Users retrieved successfully", users);
    } catch (error) {
        console.error("Error in getAllUsers:", error);
        return response(res, 500, "Internal Server Error");
    }
};

const searchUsers = async (req, res) => {
    const activeUserId = req.user._id;
    const { q } = req.query;

    if (!q) {
        return response(res, 400, "Search query is required");
    }

    try {
        // Case-insensitive regex match on username, email, or phone
        const regex = new RegExp(q, 'i');
        const users = await User.find({
            _id: { $ne: activeUserId },
            $or: [
                { username: regex },
                { email: regex },
                { phoneNumber: regex }
            ]
        }).select('-emailOtp -emailOtpExpiry');

        return response(res, 200, "Users searched successfully", users);
    } catch (error) {
        console.error("Error in searchUsers:", error);
        return response(res, 500, "Internal Server Error");
    }
};

module.exports = { getAllUsers, searchUsers };
