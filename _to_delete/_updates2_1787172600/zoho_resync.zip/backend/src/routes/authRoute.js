const express = require('express');
const authController = require('../controllers/authController');
const protectRoute = require('../middleware/authMiddleware');
const upload = require('../middleware/uploadMiddleware');

const router = express.Router();

router.post('/send-otp', authController.sendOtp);
router.post('/verify-otp', authController.verifyOtp);
router.get('/check-auth', protectRoute, authController.checkAuth);
router.put('/update-profile', protectRoute, upload.single('profilePicture'), authController.updateProfile);

module.exports = router;



