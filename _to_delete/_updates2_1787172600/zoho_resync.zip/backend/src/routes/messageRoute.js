const express = require('express');
const { sendMessage, getMessages, markMessagesAsSeen } = require('../controllers/messageController');
const protectRoute = require('../middleware/authMiddleware');
const upload = require('../middleware/uploadMiddleware');

const router = express.Router();

router.post('/send', protectRoute, upload.single('file'), sendMessage);
router.get('/:conversationId', protectRoute, getMessages);
router.post('/seen/:conversationId', protectRoute, markMessagesAsSeen);

module.exports = router;
