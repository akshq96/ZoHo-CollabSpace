const multer = require('multer');

const storage = multer.memoryStorage();

const upload = multer({
  storage: storage,
  limits: {
    fileSize: 25 * 1024 * 1024 // 25 MB limit
  },
  fileFilter: (req, file, cb) => {
    // Allow images, videos, audio, documents, archives, and code files
    cb(null, true);
  }
});

module.exports = upload;
