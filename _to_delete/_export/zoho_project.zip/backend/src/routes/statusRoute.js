const express = require('express');
const { createStatus, getStatuses } = require('../controllers/statusController');
const protectRoute = require('../middleware/authMiddleware');
const upload = require('../middleware/uploadMiddleware');

const router = express.Router();

router.post('/', protectRoute, upload.single('media'), createStatus);
router.get('/', protectRoute, getStatuses);

module.exports = router;
